<div id="header" class="corporate-nav-style">
			<div class="navbar-area">
				<!-- Menu For Mobile Device -->
				<div class="mobile-nav">
					<a href="index.php" class="logo">
						<img src="assets/img/white-logo.png" alt="Sri Systems Inc">
					</a>
				</div>

				<!-- Menu For Desktop Device -->
				<div class="main-nav">
					<nav class="navbar navbar-expand-md navbar-light">
						<div class="container">
							<a class="navbar-brand" href="index.php">
								<img src="assets/img/white-logo.png" alt="Sri Systems Inc">
							</a>
	
							<div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
								<ul class="navbar-nav ml-auto">
								    <li class="nav-item">
										<a href="" class="nav-link dropdown-toggle">
											Company
										</a>
										<ul class="dropdown-menu dropdown-style">
											<li class="nav-item">
												<a href="about.php" class="nav-link">About Us </a>
											</li>
											
											
										</ul>
									</li>
									
									<li class="nav-item">
										<a href="#" class="nav-link dropdown-toggle">
											Salesforce
										</a>
										<ul class="dropdown-menu dropdown-style">
											<li class="nav-item">
												<a href="#" class="nav-link">Salesforce Services </a>
											</li>
											<li class="nav-item">
												<a href="#" class="nav-link">Salesforce CPQ </a>
											</li>
											<li class="nav-item">
												<a href="#" class="nav-link">Field Service Lightning </a>
											</li>
											<li class="nav-item">
												<a href="#" class="nav-link">Salesforce CoE </a>
											</li>
											<li class="nav-item">
												<a href="#" class="nav-link">Salesforce Industries </a>
											</li>
										</ul>
									</li>
									<li class="nav-item">
										<a href="" class="nav-link dropdown-toggle">
											Technologies
										</a>
										<ul class="dropdown-menu dropdown-style">
											
											<li class="nav-item">
												<a href="tsf-crm.php" class="nav-link">SalesForce CRM  </a>
											</li>
											<li class="nav-item">
												<a href="tsf-automation.php" class="nav-link"> Sales Automation  </a>
											</li>
											<li class="nav-item">
												<a href="tsf-api-integration.php" class="nav-link">Api Integration</a>
											</li>
											
											
											<li class="nav-item">
												<a href="tsf-servicemax.php" class="nav-link">ServiceMax   </a>
											</li>
											
											<li class="nav-item">
												<a href="#" class="nav-link">Vlocity</a>
											</li>
											
										</ul>
									</li>
									<li class="nav-item">
										<a href="" class="nav-link dropdown-toggle">
											Vertical
										</a>
										<ul class="dropdown-menu dropdown-style">
										
											 <li class="nav-item">
												<a href="velocity-bsfi.php" class="nav-link">BFSI</a>
											</li>
											<li class="nav-item">
												<a href="velocity-ite-commerce.php" class="nav-link">IT/E-Commerce    </a>
											</li>
											<li class="nav-item">
												<a href="velocity-retailsupply-chain.php" class="nav-link"> Retail/Supply Chain  </a>
											</li>
											<li class="nav-item">
												<a href="#" class="nav-link">Utilities/Energy </a>
											</li>
											<li class="nav-item">
												<a href="#" class="nav-link">Healthcare  </a>
											</li>
											<li class="nav-item">
												<a href="#" class="nav-link">In-House Projects</a>
											</li>
											<li class="nav-item">
												<a href="#" class="nav-link">Pipeline Projects </a>
											</li>
										</ul>
									</li>
									<li class="nav-item">
										<a href="landing.php" class="nav-link">Training</a>
									</li>
									<li class="nav-item">
										<a href="" class="nav-link dropdown-toggle">
											Marketing Cloud
										</a>
										<ul class="dropdown-menu dropdown-style">
										
											 <li class="nav-item">
												<a href="salesforce-marketing-cloud.php" class="nav-link">Salesforce Marketing Cloud</a>
											</li>
											
											
										</ul>
									</li>
									
									<li class="nav-item">
										<a href="" class="nav-link">
											Careers
										</a>
										
									</li>
									
									
									<li class="nav-item">
										<a href="contact.php" class="nav-link">Contact</a>
									</li>
									
								</ul>
								
							</div>
						</div>
					</nav>
				</div>
			</div>
		</div>